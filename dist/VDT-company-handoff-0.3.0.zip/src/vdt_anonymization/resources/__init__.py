"""Bundled offline data resources."""
