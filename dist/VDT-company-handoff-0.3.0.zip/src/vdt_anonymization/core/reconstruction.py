"""Evidence-first reconstruction: observe -> type -> link -> plan -> validate.

Each stage consumes the previous stage's decisions. Lexical similarity alone
cannot establish a type. Uncertain observations never propagate labels.
"""
import hashlib
import re
from collections import defaultdict

from .gazetteer import (
    UNITS as ADMIN_UNITS,
    admin_path_candidates,
    names as admin_names,
    parent_components,
    record_for_name,
    spacing_repairs as admin_spacing_repairs,
)
from .lexicon import (
    FAMILY_NAMES,
    GIVEN_NAMES,
    LOCATION_NAMES,
    NAME_PREFIX_TOKENS,
    SKEWED_FAMILY_NAMES,
    SYNTHETIC_ORGANIZATION_NAMES,
)

VERSION = "evidence-v6"
CODE_RE = re.compile(r"(?:NLQ|NLC)\s*\d+")
# A separator followed by a three-digit group starts a Vietnamese-formatted
# amount (``H 150.000 đồng``), not an identity ordinal.  The trailing word
# boundary in TOKEN_RE prevents the engine from backtracking to H15/H1.
ORDINAL = r"[1-9]\d*(?![.,]\d{3})"
DOTTED = rf"(?:[A-ZĐ]\.){{1,5}}[A-ZĐ](?:{ORDINAL})?"
MULTI_INITIAL = rf"(?:Th|Ph|Tr|Ng|Ch|Kh|Nh)(?:[ \t]*{ORDINAL})?"
TOKEN_RE = re.compile(
    rf"(?<![A-ZĐ\d_])(?:NLQ\s*\d+|NLC\s*\d+|{DOTTED}|"
    rf"[IVX]{{2,6}}|{MULTI_INITIAL}|[A-ZĐ](?:[ \t]*{ORDINAL})?)(?!\w)"
)
PERSON_TITLE = re.compile(r"(?<!\w)(ông|bà|anh|chị|cháu|cô|chú|bác|em)\s*$", re.I)
DECLARATION = re.compile(r"(nguyên đơn|bị đơn|bị cáo|bị hại|người làm chứng|người khởi kiện|người bị kiện)\s*:\s*(?:(?:ông|bà|anh|chị|cháu)\s*)?$", re.I)
ORG_PREFIX = re.compile(r"(?<!\w)(ngân hàng(?: thương mại cổ phần)?|công ty(?: trách nhiệm hữu hạn| cổ phần| tnhh)?|hợp tác xã|chi cục(?: thi hành án dân sự)?|ủy ban nhân dân)\s*$", re.I)
ADDRESS_UNITS = {
    "số": "house_number", "số nhà": "house_number", "tầng": "floor", "lầu": "floor",
    "phòng": "room", "căn": "room", "thửa": "parcel", "lô": "parcel",
    "ấp": "hamlet", "thôn": "hamlet", "làng": "hamlet", "khóm": "hamlet",
    "khu phố": "hamlet", "tổ": "hamlet", "tổ dân phố": "hamlet",
    "xã": "commune", "phường": "commune", "thị trấn": "commune",
    "huyện": "district", "quận": "district", "thị xã": "district",
    "thành phố": "city", "tỉnh": "province", "đường": "street", "lộ": "street",
    "quốc lộ": "road_number", "ngõ": "street", "hẻm": "street",
}
ADDRESS_UNITS.setdefault("xóm", "hamlet")
UNIT_PATTERN = "|".join(re.escape(s) for s in sorted(ADDRESS_UNITS, key=len, reverse=True))
ADDRESS_PREFIX = re.compile(rf"(?<!\w)({UNIT_PATTERN})\s*$", re.I)
NONENTITY_PREFIX = re.compile(r"(?:loại|mã|ký hiệu|biển số|số hiệu|điểm|hạng|nhóm)\s*$", re.I)
IDENTIFIER_PREFIX = re.compile(
    r"(?:giấy\s+chứng\s+nhận(?:\s+quyền\s+sử\s+dụng\s+đất)?|hộ\s+chiếu|"
    r"căn\s+cước(?:\s+công\s+dân)?|chứng\s+minh(?:\s+nhân\s+dân)?|hợp\s+đồng|"
    r"tài\s+khoản|đăng\s+ký(?:\s+kinh\s+doanh)?|biên\s+lai|hóa\s+đơn|"
    r"biển\s+(?:kiểm\s+soát|số)|mã)\b[^.;:\n]{0,80}\bsố\s*$",
    re.I,
)
FOREIGN_RE = re.compile(r"Đài Loan|Trung Quốc|Australia|Sydney|Hoa Kỳ|Hàn Quốc|Nhật Bản", re.I)
GENDER = {"ông":"male", "anh":"male", "chú":"male", "bà":"female", "chị":"female", "cô":"female"}
NEUTRAL = ["Anh", "An", "Bình", "Hà", "Minh", "Thanh", "Tâm"]
MIDDLES = ["Văn", "Thị", "Hữu", "Đức", "Ngọc", "Quốc", "Hoàng", "Thanh", "Minh", "Gia", "Xuân"]

# Broader, familiar Vietnamese place vocabulary. These are synthetic values,
# not attempts to recover the source location. Keeping several alternatives
# per administrative role prevents every document from cycling through the
# same small set of two-syllable names.
PROVINCE_NAMES = list(dict.fromkeys(admin_names('tỉnh') + admin_names('thành phố')))

LOCATION_VARIANTS = {
    "district": [
        "An Bình", "Bình Minh", "Cao Lãnh", "Đức Hòa", "Đông Hòa",
        "Hòa Thành", "Long Thành", "Minh Long", "Nam Giang", "Phú Bình",
        "Quế Sơn", "Tân Châu", "Thuận Thành", "Vạn Ninh", "Xuân Lộc",
    ],
    "commune": [
        "An Hòa", "Bình An", "Cẩm Tú", "Đông Phú", "Hòa Bình",
        "Long Hưng", "Minh Tân", "Nam Sơn", "Phú An", "Quang Trung",
        "Tân Lập", "Thanh Sơn", "Vĩnh Hòa", "Xuân Thịnh", "Yên Phú",
    ],
    "hamlet": [
        "An Bình", "Bình Hòa", "Cầu Mới", "Đông Bình", "Hòa Phú",
        "Long Bình", "Minh Tân", "Nam Bình", "Phú Bình", "Quang Trung",
        "Tân Bình", "Thanh Bình", "Vĩnh Bình", "Xuân Bình", "Yên Bình",
    ],
}


def normalize(value):
    return re.sub(r"\s+", " ", value).strip().casefold()


def marker_value(value):
    value = re.sub(r"\s+", "", str(value or ""))
    return value if re.fullmatch(rf"(?:NLQ|NLC)\d+|{DOTTED}|{MULTI_INITIAL}|[A-ZĐ](?:[1-9]\d*)?", value) else None


def numeric_suffix(value):
    match = re.search(r"(\d+)$", re.sub(r"\s+", "", str(value or "")))
    return int(match.group(1)) if match else None


def stable_slot(doc_id, key):
    return int.from_bytes(hashlib.sha256(f"{doc_id}|{key}".encode()).digest()[:8], 'big')


def issue(mention, reason):
    if reason not in mention["review_reasons"]:
        mention["review_reasons"].append(reason)


def prefix_before(text, start):
    """Recognize a contiguous name prefix; never scan across punctuation."""
    before = text[max(0,start-100):start]
    words = list(re.finditer(r"[^\W\d_]+", before))
    chosen = []
    end = len(before)
    for word in reversed(words):
        if before[word.end():end].strip():
            break
        token = word.group()
        if not token[0].isupper() or normalize(token) not in NAME_PREFIX_TOKENS:
            break
        chosen.insert(0, token)
        end = word.start()
        if len(chosen) == 5:
            break
    if not chosen or normalize(chosen[0]) not in {normalize(s) for s in FAMILY_NAMES}:
        return start, ""
    return max(0,start-100)+end, " ".join(chosen)


def observations(text, ner_record):
    """Keep original NER evidence separate from final entity decisions."""
    result = []
    for entity in (ner_record or {}).get('entities', []):
        start, end = entity.get('start'), entity.get('end')
        if not isinstance(start, int) or not isinstance(end, int) or not (0 <= start < end <= len(text)):
            continue
        label = str(entity.get('label','')).upper().split('-')[-1]
        label = {'PERSON':'PER', 'LOCATION':'LOC', 'ORGANIZATION':'ORG'}.get(label,label)
        if label in {'PER','LOC','ORG'}:
            observation={'start':start,'end':end,'label':label,'score':entity.get('score'),'text':text[start:end]}
            if label in {'PER','LOC'}:
                view, repairs=repair_ner_spacing(text,start,end,[observation])
                observation['normalized_text']=view
                observation['ocr_spacing_repairs']=repairs
            result.append(observation)
    return result


def repair_ner_spacing(text, start, end, ner):
    """Repair dictionary-supported spacing only in a matching view.

    Offsets and source text remain untouched. Complete PER spans may include
    markers, which are protected. Repairs cannot cross punctuation or lines.
    """
    edits = {}
    for observation in ner:
        left, right = max(start, observation['start']), min(end, observation['end'])
        if left >= right:
            continue
        vocabulary = FAMILY_NAMES if observation['label']=='PER' else list(ADDRESS_UNITS)
        if observation['label']=='LOC':
            vocabulary = list(dict.fromkeys(vocabulary + PROVINCE_NAMES +
                [name for groups in LOCATION_NAMES.values() for names in groups.values() for name in names] +
                [name for names in LOCATION_VARIANTS.values() for name in names]))
        fragment = text[left:right]
        if observation['label'] in {'LOC','ORG'}:
            for edit in admin_spacing_repairs(text,left,right):
                if not any(edit['start'] < left+m.end() and edit['end'] > left+m.start()
                           for m in TOKEN_RE.finditer(fragment)):
                    edits[(edit['start'],edit['end'])]=edit
        for word in vocabulary:
            pattern = r'(?<!\w)' + r'[ \t]*'.join(re.escape(c) for c in word.replace(' ','')) + r'(?!\w)'
            for match in re.finditer(pattern, fragment, re.I):
                raw = match.group()
                if normalize(raw) == normalize(word):
                    continue
                a, b = left+match.start(), left+match.end()
                # An isolated capital, dotted initial or procedural code may
                # be deliberate anonymization; do not absorb it into a word.
                if any(a < left+m.end() and b > left+m.start()
                       for m in TOKEN_RE.finditer(fragment)):
                    continue
                edits[(a,b)] = {'start':a,'end':b,'original':raw,'normalized':word}
    ordered = sorted(edits.values(),key=lambda e:(e['start'],-e['end']))
    accepted=[]
    for edit in ordered:
        if not accepted or edit['start']>=accepted[-1]['end']:
            accepted.append(edit)
    view=text[start:end]
    for edit in reversed(accepted):
        view=view[:edit['start']-start]+edit['normalized']+view[edit['end']-start:]
    return view, accepted


def location_prefix_lookback(text, start):
    """Match an address unit across at most three preceding whitespace tokens.

    Only whitespace edits are permitted; punctuation/newlines and isolated
    uppercase markers cannot be crossed. The caller must supply LOC evidence.
    """
    before=text[max(0,start-100):start]
    match=re.search(r'([^\W\d_]+(?:[ \t]+[^\W\d_]+){0,2})[ \t]*$',before)
    if not match:
        return None
    words=list(re.finditer(r'[^\W\d_]+',match.group(1)))
    for count in range(1,len(words)+1):
        chosen=words[-count:]
        a=max(0,start-100)+match.start(1)+chosen[0].start()
        b=max(0,start-100)+match.start(1)+chosen[-1].end()
        raw=text[a:b]
        if any(len(w.group())==1 and w.group().isupper() for w in chosen):
            continue
        compact=normalize(''.join(w.group() for w in chosen))
        options=[unit for unit in ADDRESS_UNITS if unit.replace(' ','')==compact]
        if len(options)==1:
            return {'start':a,'end':b,'original':raw,'normalized':options[0]}
    return None


def detect_candidates(text, ner_record):
    ner = observations(text, ner_record)
    candidates = []
    for match in TOKEN_RE.finditer(text):
        start, end = match.span()
        token = re.sub(r"\s+", "", match.group())
        before = text[max(0,start-150):start]
        after = text[end:end+120]
        overlapping = [n for n in ner if n['start'] <= start and n['end'] >= end]
        before, spacing_repairs = repair_ner_spacing(text,max(0,start-150),start,overlapping)
        if any(n['label']=='LOC' for n in overlapping):
            extension=location_prefix_lookback(text,start)
            if extension and normalize(extension['original'])!=extension['normalized']:
                before=text[max(0,start-150):extension['start']]+extension['normalized']+text[extension['end']:start]
                if extension not in spacing_repairs:
                    spacing_repairs.append(extension)
        m = dict(start=start,end=end,text=text[start:end],marker=token,label='UNKNOWN',
                 score=None,ner_evidence=overlapping,detectors=['lexical'],
                 link_evidence='unconfirmed',encoding_scheme='unconfirmed',link_status='unconfirmed_marker',
                 review_reasons=[],person_anchor=None,role='unknown')
        candidates.append(m)
        if spacing_repairs:
            m['ocr_spacing_repairs']=spacing_repairs
            m['detectors'].append('ner_spacing_repair')
        # Reject lexical fragments of identifiers. Rejection is occurrence-local.
        if start and text[start-1].isalnum() and not text[start-1].islower():
            m['link_status']='rejected_nonentity'; m['link_evidence']='inside_uppercase_word_or_identifier'; continue
        if re.match(r'[Vv]/[Vv](?!\w)',text[start:start+4]) or (start and text[start-1] in '/_'):
            m['link_status']='rejected_nonentity'; m['link_evidence']='abbreviation_or_identifier'; continue
        if NONENTITY_PREFIX.search(before):
            m['link_status']='rejected_nonentity'; m['link_evidence']='technical_or_enumeration_context'; continue
        if IDENTIFIER_PREFIX.search(before):
            m['link_status']='rejected_nonentity'; m['link_evidence']='document_identifier_context'; continue
        if numeric_suffix(token) is not None and re.match(r'\s*/\s*\d', after):
            m['link_status']='rejected_nonentity'; m['link_evidence']='compound_literal_number'; continue
        # Section-number protection is intentionally case-sensitive. A legal
        # organization such as ``Ngân hàng thương mại cổ phần X`` contains
        # lowercase ``phần`` immediately before its anonymized marker; that
        # must not be mistaken for a ``PHẦN X`` heading.
        if re.search(r'(?:Page|PHẦN|MỤC)\s*$',before):
            m['link_status']='rejected_nonentity'; m['link_evidence']='section_number'; continue

        address = ADDRESS_PREFIX.search(before)
        organization = ORG_PREFIX.search(before)
        title = PERSON_TITLE.search(before)
        declaration = DECLARATION.search(before)
        prefix_start, prefix = prefix_before(text,start)
        if CODE_RE.fullmatch(match.group()):
            m.update(encoding_scheme='procedural_code',person_anchor='code:'+token,
                     link_status='unresolved_type',link_evidence='explicit_procedural_code',
                     procedural_role='witness' if token.startswith('NLC') else 'related_party')
            if title or re.match(r'\s*[,;]?\s*sinh năm\s*:?\s*\d{4}',after,re.I) or token.startswith('NLC'):
                m['label']='PER'
            if organization:
                m['label']='ORG'; m['organization_form']=organization.group(1)
        elif address:
            unit=normalize(address.group(1)); role=ADDRESS_UNITS[unit]
            m.update(label='ADDR' if role in {'house_number','floor','room','parcel','road_number'} else 'LOC',
                     role=role,address_unit=unit,encoding_scheme='component_alias',link_status='typed',
                     link_evidence='direct_address_grammar')
            # An actual numbered unit and a publication alias are indistinguishable
            # from typography alone. Never convert Roman I into a random place.
            if re.fullmatch(r'I+|IV|VI+|IX|XI+', token):
                issue(m,'numeral_or_alias')
            tail = re.split(r'[;\n.!?]',text[end:end+250])[0]
            parents = parent_components(tail)
            m['address_parents']=parents
            m['identity_scope']='|'.join(parents)
            block = text[max(0,start-120):end+250].split('\nNỘI DUNG')[0]
            if FOREIGN_RE.search(block): issue(m,'unsupported_foreign_address')
            if role=='road_number': issue(m,'road_number_or_alias')
        elif organization:
            m.update(label='ORG',role='organization',encoding_scheme='component_alias',
                     organization_form=normalize(organization.group(1)),link_status='typed',link_evidence='direct_organization_grammar')
        elif prefix:
            m.update(label='PER',role='person',start=prefix_start,text=text[prefix_start:end],
                     name_prefix=prefix,encoding_scheme='numbered_initial' if any(c.isdigit() for c in token) else 'name_initial',
                     person_anchor=normalize(prefix),link_status='explicit_anchor',link_evidence='contiguous_name_prefix')
            title=PERSON_TITLE.search(text[max(0,prefix_start-80):prefix_start])
            declaration=DECLARATION.search(text[max(0,prefix_start-150):prefix_start])
        elif title or declaration:
            m.update(label='PER',role='person',encoding_scheme='dotted_initials' if '.' in token else 'whole_name_alias',
                     link_status='typed',link_evidence='direct_person_grammar')
        elif overlapping:
            labels={n['label'] for n in overlapping}
            m.update(detectors=['lexical','ner'],encoding_scheme='dotted_initials' if '.' in token else 'whole_name_alias')
            if len(labels)==1:
                m.update(label=next(iter(labels)),link_status='typed',link_evidence='ner_observation')
            else:
                m.update(link_status='type_conflict',type_candidates=sorted(labels));issue(m,'conflicting_ner_types')
            # Retain a complete NER name prefix, but never invent a Vietnamese
            # replacement for an unsupported name family (e.g. Liao, Chih).
            if m['label']=='PER':
                best=max(overlapping,key=lambda n:n['end']-n['start'])
                surface, repairs=repair_ner_spacing(text,best['start'],start,[best])
                surface=surface.strip()
                if repairs:
                    m['ocr_spacing_repairs']=repairs
                surface=re.sub(r'^(?:ông|bà|anh|chị|cháu)\s+','',surface,flags=re.I)
                if surface:
                    m.update(start=best['start'],text=text[best['start']:end],label='PER',role='person',name_prefix=surface,
                             person_anchor=normalize(surface),encoding_scheme='name_initial')
                    # A partially masked NER span is not automatically an
                    # unsupported name.  Recognized Vietnamese family names
                    # (e.g. Nguyễn Phát Q) are valid anchors and should be
                    # allowed to reach the compatible given-name generator.
                    family_head=normalize(surface.split()[0]) if surface.split() else ''
                    known_families={normalize(name) for name in FAMILY_NAMES}
                    if family_head not in known_families:
                        issue(m,'unsupported_name_prefix')
        suffix = numeric_suffix(token)
        if suffix is not None and suffix >= 20 and m['link_status'] != 'rejected_nonentity':
            issue(m, 'large_numeric_suffix_requires_repetition')
        # All other tokens stay UNKNOWN. Knowing that another M is a person
        # cannot turn this occurrence into a person or a place.
        if title:
            m['gender']=GENDER.get(title.group(1).casefold())
        if m.get('name_prefix'):
            if re.search(r'\bThị\b',m['name_prefix']):m['gender']='female'
            elif re.search(r'\bVăn\b',m['name_prefix']):m['gender']='male'
        if declaration:
            m['declaration']=True; m['procedural_role']=normalize(declaration.group(1))
        # A lexical fragment must not be reconstructed as an independent person.
        next_word=re.match(r'\s+([^\W\d_]+)',after)
        if next_word and normalize(token+next_word.group(1)) in {normalize(s) for s in FAMILY_NAMES}:
            issue(m,'fragmented_surname')
        if m.get('name_prefix') and re.match(r'\s+[a-zđ](?!\w)',after):
            issue(m,'fragmented_initial')
        if '.' in token and m['label']=='PER':
            m.update(encoding_scheme='dotted_initials',person_anchor='dotted:'+token,link_status='explicit_code')
        if m['label']=='LOC' and not address:
            issue(m,'location_without_address_structure')
        if m['label']=='ORG' and not organization and m['encoding_scheme']!='procedural_code':
            issue(m,'organization_without_form')
        if overlapping:
            m['detectors']=sorted(set(m['detectors'])|{'ner'})
            m['score']=None # NER confidence is retained only in ner_evidence.
        if m['link_status']=='unconfirmed_marker':issue(m,'unconfirmed_marker')
    return candidates, ner


def link_candidates(text, mentions, resolver=None, doc_id=''):
    """Build typed registries, then attach independently typed references."""
    registry=defaultdict(lambda:defaultdict(list))
    codes=defaultdict(list)
    for m in mentions:
        if m['encoding_scheme']=='procedural_code': codes[m['marker']].append(m)
        elif m['label']=='PER' and m.get('person_anchor'):
            registry[m['marker']][m['person_anchor']].append(m)
    for code, peers in codes.items():
        types={m['label'] for m in peers if m['label']!='UNKNOWN'}
        for m in peers:
            if len(types)==1:
                m.update(label=next(iter(types)),link_status='explicit_code',role='person' if 'PER' in types else 'organization')
            else:
                m.update(label='UNKNOWN',link_status='unresolved_type')
                issue(m,'unknown_participant_type' if not types else 'conflicting_participant_types')
    if resolver:
        resolver.resolve_types(doc_id,text,mentions)

    # A numbered marker can be introduced once as a complete person name and
    # then appear alone in enumerations, delegation clauses, or later
    # references.  The standalone occurrence is not independently typeable,
    # but a unique person anchor for the exact marker is strong document-local
    # evidence.  Propagate only when that marker has no competing typed label;
    # this keeps L1 distinct from L2/L10 and prevents a person marker from
    # absorbing an address, organization, or identifier with the same text.
    typed_labels = defaultdict(set)
    for mention in mentions:
        if mention.get('link_status') == 'rejected_nonentity':
            continue
        if mention.get('label') != 'UNKNOWN':
            typed_labels[mention['marker']].add(mention['label'])
    for mention in mentions:
        if mention.get('link_status') != 'unconfirmed_marker':
            continue
        if not any(char.isdigit() for char in mention['marker']):
            continue
        choices = registry[mention['marker']]
        if len(choices) != 1 or typed_labels[mention['marker']] - {'PER'}:
            continue
        anchor = next(iter(choices))
        mention.update(
            label='PER',
            role='person',
            person_anchor=anchor,
            encoding_scheme='numbered_initial' if any(c.isdigit() for c in mention['marker']) else 'name_initial',
            link_status='linked_by_unique_anchor',
            link_evidence='unique_marker_anchor',
        )
        mention['review_reasons'] = [
            reason for reason in mention['review_reasons'] if reason != 'unconfirmed_marker'
        ]
    # Large ordinals are rare but possible in multi-party cases.  Admit one
    # only when the exact marker occurs at least twice, resolves to one person
    # anchor, and never receives another type.  A single ``H150`` next to an
    # amount or identifier therefore cannot enter the clean set.
    for marker, anchors in registry.items():
        suffix = numeric_suffix(marker)
        peers = [m for m in mentions if m['marker'] == marker and m.get('link_status') != 'rejected_nonentity']
        if suffix is None or suffix < 20 or len(peers) < 2 or len(anchors) != 1:
            continue
        if any(m.get('label') not in {'PER', 'UNKNOWN'} for m in peers):
            continue
        for mention in peers:
            mention['review_reasons'] = [
                reason for reason in mention['review_reasons']
                if reason != 'large_numeric_suffix_requires_repetition'
            ]
    declarations=defaultdict(list)
    for m in mentions:
        if m['label']=='PER' and m.get('declaration') and not m.get('person_anchor'):
            declarations[m['marker']].append(m)
    for code, peers in declarations.items():
        if len(peers)==1 and not registry[code]:
            registry[code]['alias:'+code]=peers
    for m in mentions:
        if m['label']!='PER' or m.get('person_anchor'):continue
        choices=registry[m['marker']]
        if len(choices)==1:
            anchor=next(iter(choices)); m.update(person_anchor=anchor,link_status='linked_by_unique_anchor')
            if anchor.startswith('alias:'):m['link_status']='declared_alias'
        else:
            m['link_status']='ambiguous_marker';issue(m,'ambiguous_identity' if choices else 'missing_identity_anchor')
    if resolver:
        resolver.resolve(doc_id,text,mentions)
        for m in mentions:
            if m.get('llm_decision',{}).get('status')=='accepted':
                m['review_reasons']=[r for r in m['review_reasons'] if r not in {'ambiguous_identity','missing_identity_anchor','unknown_participant_type','conflicting_ner_types','unconfirmed_marker'}]
                issue(m,'llm_decision_requires_review')
    # Unmasked NER names are evidence for review, not reliable identities to
    # copy into the synthetic dataset. No implicit "known_full_name" recovery.
    return mentions


def person_value(doc_id,key,group,used):
    genders={m.get('gender') for m in group if m.get('gender')}
    # Gender improves realism when available, but it is not an identity
    # constraint. Court text can omit titles or contain inconsistent ones.
    # Fall back to a neutral pool instead of blocking a valid initial.
    gender=next(iter(genders)) if len(genders)==1 else None
    prefixes={m.get('name_prefix') for m in group if m.get('name_prefix')}
    if len(prefixes)>1:return None,'conflicting_name_prefixes'
    prefix=next(iter(prefixes)) if prefixes else ''
    marker=group[0]['marker']; dotted=group[0]['encoding_scheme']=='dotted_initials'
    families=SKEWED_FAMILY_NAMES
    middles=['Thị'] if gender=='female' else ['Văn'] if gender=='male' else ['']
    neutral_pool=list(dict.fromkeys(
        n for gender_values in GIVEN_NAMES.values() for values in gender_values.values() for n in values
    ))
    pool=list(dict.fromkeys(n for values in GIVEN_NAMES[gender].values() for n in values)) if gender else neutral_pool
    if dotted:
        letters=marker.split('.')
        if len(letters)!=3 or any(len(s)!=1 for s in letters):return None,'unsupported_dotted_initials'
        families=[n for n in families if n[0]==letters[0]]
        middles=[n for n in MIDDLES if n[0]==letters[1]]
        if gender=='female':middles=[n for n in middles if n not in {'Văn','Hữu','Quốc'}]
        if gender=='male':middles=[n for n in middles if n!='Thị']
        pool=[n for n in pool if n[0]==letters[-1]]
    elif prefix:
        initial=re.sub(r'\d+$','',marker)
        pool=[n for n in pool if n.startswith(initial)]
        if not pool and gender:
            pool=[n for n in neutral_pool if n.startswith(initial)]
    if not pool or not families or not middles:return None,'no_compatible_synthetic_name'
    offset=stable_slot(doc_id,key)
    for i in range(len(pool)*len(families)*len(middles)):
        p=pool[(offset+i)%len(pool)]
        family=families[((offset+i)//len(pool))%len(families)]
        middle=middles[((offset+i)//(len(pool)*len(families)))%len(middles)]
        value=f'{prefix} {p}' if prefix else ' '.join(s for s in (family,middle,p) if s)
        if value not in used:
            used.add(value);return value,None
    return None,'synthetic_name_pool_exhausted'


ADMIN_LOCATION_ROLES={'province','district','commune'}


def split_address_component(component):
    component=normalize(component)
    for unit in sorted(ADDRESS_UNITS,key=len,reverse=True):
        prefix=normalize(unit)+' '
        if component.startswith(prefix):
            return unit,component[len(prefix):].strip()
    return None,None


def is_masked_address_value(value):
    return marker_value(str(value or '').upper()) is not None


def plan_admin_location_values(doc_id, groups):
    """Plan masked administrative names from one valid hierarchy per scope."""
    location_groups=[
        (key,group) for key,group in groups.items()
        if group and group[0]['label']=='LOC'
        and group[0].get('role') in ADMIN_LOCATION_ROLES
    ]
    if not location_groups:
        return {}

    signatures=[]
    for key,group in location_groups:
        masked=set()
        anchors={}
        required=defaultdict(set)
        first=group[0]
        required[first['role']].add(first.get('address_unit'))
        masked.add((first['role'],normalize(first.get('marker'))))
        for mention in group:
            for component in mention.get('address_parents',[]):
                unit,value=split_address_component(component)
                if not unit:
                    continue
                record=record_for_name(unit,value)
                if record:
                    anchors[record['code']]=record
                    continue
                role=ADDRESS_UNITS.get(unit)
                if role in ADMIN_LOCATION_ROLES and is_masked_address_value(value):
                    masked.add((role,normalize(value)))
        signatures.append((key,group,masked,anchors,required))

    # Connect entities that occur in the same masked address chain. Visible
    # parents constrain a chain but do not accidentally merge two unrelated
    # addresses in the same province.
    components=[]
    by_signature={item[0]:item for item in signatures}
    unvisited=set(by_signature)
    while unvisited:
        root=next(iter(unvisited))
        pending={root}; changed=True
        while changed:
            changed=False
            for other in tuple(unvisited-pending):
                other_signature=by_signature[other][2]
                if any(by_signature[key][2] & other_signature for key in pending):
                    pending.add(other)
                    changed=True
        components.append(pending)
        unvisited-=pending

    by_key={item[0]:item for item in signatures}
    planned={}
    for component in components:
        anchors={}
        required=defaultdict(set)
        for key in component:
            _,group,_,group_anchors,group_required=by_key[key]
            anchors.update(group_anchors)
            for role,units in group_required.items():
                required[role].update(units)
        required_tuple=tuple(sorted((role,tuple(sorted(units))) for role,units in required.items()))
        paths=admin_path_candidates(tuple(sorted(anchors)),required_tuple)
        if not paths:
            for key in component:
                planned[key]=(None,'invalid_location_hierarchy')
            continue
        seed=tuple(sorted(str(key) for key in component))
        path=dict(paths[stable_slot(doc_id,('location_path',seed))%len(paths)])
        for key in component:
            first=by_key[key][1][0]
            role=first.get('role')
            record=path.get(role)
            if record:
                planned[key]=(record['name'],None)
    return planned


def replacement_value(doc_id,key,group,used,planned_locations=None):
    first=group[0]; label=first['label']; role=first['role']
    hard={r for m in group for r in m['review_reasons'] if r!='llm_decision_requires_review'}
    if hard:return None,sorted(hard)[0]
    if label=='PER':return person_value(doc_id,key,group,used)
    if label=='UNKNOWN':return None,'unknown_entity_type'
    slot=stable_slot(doc_id,key)
    if label=='ORG':
        if first['encoding_scheme']=='procedural_code':
            return None,'organization_code_needs_full_form'
        pool=SYNTHETIC_ORGANIZATION_NAMES
    elif label=='LOC':
        if planned_locations is not None and key in planned_locations:
            return planned_locations[key]
        unit=role if role in LOCATION_NAMES else 'generic'
        pool=list(dict.fromkeys(s for values in LOCATION_NAMES[unit].values() for s in values))
        if first.get('address_unit') in ADMIN_UNITS:
            pool=[name for name in admin_names(first['address_unit']) if not name.isdigit()]
        else:
            pool=list(dict.fromkeys(LOCATION_VARIANTS.get(unit,[])+pool))
    elif label=='ADDR':
        ranges={
            'floor': (1, 8),
            'house_number': (1, 300),
            'room': (101, 508),
            'parcel': (1, 300),
            'road_number': (1, 300),
        }
        low,high=ranges.get(role,(1,300))
        return str(low+slot%(high-low+1)),None
    else:return None,'unsupported_entity_type'
    for i in range(len(pool)):
        value=pool[(slot+i)%len(pool)]
        if value not in used:used.add(value);return value,None
    return None,'synthetic_pool_exhausted'


def build_entities(doc_id,text,mentions,ner):
    groups=defaultdict(list)
    for m in mentions:
        if m['link_status']=='rejected_nonentity':continue
        if m['encoding_scheme']=='procedural_code':key=('code',m['marker'])
        elif m['label']=='PER' and m.get('person_anchor'):key=('PER',m['marker'],m['person_anchor'])
        elif m['label']=='LOC' and m.get('address_unit'):
            key=('LOC',m['address_unit'],m['marker'])
        elif m['label']=='ADDR' and m.get('address_unit'):
            key=(m['label'],m['address_unit'],m['marker'],m.get('identity_scope',''))
        elif m['label']=='ORG' and m.get('organization_form'):
            key=('ORG',m['organization_form'],m['marker'])
        else:key=('unresolved',m['start'],m['end'])
        groups[key].append(m)
    entities=[]; planned=[]; used=set()
    # Avoid generating an identity already present in the source.
    used.update(n['text'] for n in ner if n['label']=='PER')
    planned_locations=plan_admin_location_values(doc_id,groups)
    for index,(key,group) in enumerate(sorted(groups.items(),key=lambda item:min(m['start'] for m in item[1])),1):
        group.sort(key=lambda m:m['start']); first=group[0]
        if first['label']=='LOC' and first.get('address_unit'):
            # Missing parents are compatible with the document's established
            # alias. Compare only higher administrative levels; a stray
            # "xã hội" in a heading is not a district's parent.
            ranks={'hamlet':0,'street':0,'commune':1,'district':2,'city':2,'province':3}
            parents_by_unit=defaultdict(set)
            for mention in group:
                for parent in mention.get('address_parents',[]):
                    for unit in sorted(ADDRESS_UNITS,key=len,reverse=True):
                        if parent.startswith(unit+' '):
                            if ranks.get(ADDRESS_UNITS[unit],-1)>ranks.get(first['role'],0):
                                parents_by_unit[unit].add(parent[len(unit):].strip())
                            break
            conflict=any(len(values)>1 for values in parents_by_unit.values())
            for mention in group:
                if conflict:
                    issue(mention,'conflicting_location_parents')
                    mention['link_status']='location_parent_conflict'
                else:
                    mention['link_status']='linked_by_document_location_alias'
        for n in ner:
            if n['label']!='PER' or any(n['start']<=m['start'] and n['end']>=m['end'] for m in group):continue
            if TOKEN_RE.search(n['text']):continue
            prefix=next((m.get('name_prefix') for m in group if m.get('name_prefix')),None)
            initial = re.sub(r'\d+$','',first['marker'])
            if (prefix and normalize(n['text']).startswith(normalize(prefix)+' ')
                    and n['text'].split()[-1].startswith(initial)):
                for m in group:issue(m,'possible_unmasked_alias')
                break
        value,reason=replacement_value(doc_id,key,group,used,planned_locations)
        if reason:
            for m in group:issue(m,reason)
        eid=f"{first['label']}_{index:04d}"
        for m in group:m['entity_id']=eid
        flags=sorted({r for m in group for r in m['review_reasons']})
        entities.append(dict(entity_id=eid,label=first['label'],role=first['role'],marker=first['marker'],
                             person_anchor=first.get('person_anchor'),encoding_scheme=first['encoding_scheme'],
                             procedural_role=first.get('procedural_role'),known_full_name=None,
                             synthetic_value=value,reconstructable=value is not None,
                             link_status=first['link_status'],review_reasons=flags,
                             name_rule='compatible_synthetic' if value and first['label']=='PER' else None,
                             marker_initial_preserved=None,mentions=group))
        if value:
            for m in group:
                replacement=value
                # Preserve mention granularity: a full masked name receives
                # the full identity, while a standalone initial receives the
                # generated given name. Current given-name pools contain one
                # syllable per entry. Procedural codes/dotted names stay full.
                if (m['label']=='PER' and not m.get('name_prefix')
                        and re.fullmatch(r'[A-ZĐ](?:[ \t]*[1-9]\d*)?',m['text'])):
                    replacement=value.split()[-1]
                if m['start'] and text[m['start']-1].isalnum():replacement=' '+replacement
                if m['end']<len(text) and text[m['end']].isalnum():replacement+=' '
                planned.append(dict(entity_id=eid,label=m['label'],start=m['start'],end=m['end'],replacement=replacement))
    # Overlaps invalidate every affected entity. Never silently choose one edit.
    conflicted=set()
    ordered=sorted(planned,key=lambda p:p['start'])
    for i,p in enumerate(ordered):
        for q in ordered[i+1:]:
            if q['start']>=p['end']:break
            conflicted.update((p['entity_id'],q['entity_id']))
    for entity in entities:
        if entity['entity_id'] in conflicted:
            entity.update(reconstructable=False,synthetic_value=None)
            entity['review_reasons'].append('overlapping_replacement_spans')
            for m in entity['mentions']:issue(m,'overlapping_replacement_spans')
    return entities,[p for p in planned if p['entity_id'] not in conflicted]


def link_document(doc_id,text,ner_record,resolver=None):
    mentions,ner=detect_candidates(text,ner_record)
    link_candidates(text,mentions,resolver,doc_id)
    entities,planned=build_entities(doc_id,text,mentions,ner)
    return mentions,entities,planned


def apply_replacements(text,replacements):
    ordered=sorted(replacements,key=lambda p:(p['start'],p['end']))
    previous=0
    for p in ordered:
        if not (previous<=p['start']<p['end']<=len(text)):
            raise ValueError('Invalid or overlapping replacement plan')
        previous=p['end']
    result=text
    for p in reversed(ordered):result=result[:p['start']]+p['replacement']+result[p['end']:]
    return result,ordered
